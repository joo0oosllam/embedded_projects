/*
 * APP.c
 *
 *  Created on: Oct 30, 2023
 *      Author: Youssef Ali Sallam
 */
#include "APP.h"
#include "../MCAL/TIMER_Module/Timer_Module.h"
char *pass_stored [7] ={0,0,0,0,0,'#','\0'};
char *pass_got_from_user[7] ={0,0,0,0,0,'#','\0'};
char check_point = 1;
char count_loss = 0;
char tick = 0;

TIMER1_init_parameters_config timer1= {CTC_T1,TIMER_CLOCK_PRESCALER_DIV1024,0,Normal_OC_Disconnected_CTC,2000}; // this timer is counting 0.25 second each interrupt


void function_isr(void){
	GPIO_setupPinDirection(PORTA_ID, PIN7_ID, PIN_OUTPUT);
								GPIO_writePin(PORTA_ID, PIN7_ID, LOGIC_HIGH);

	tick++;
	if(tick == 1){
		DcMotor1_Rotate(CW, 255);


	}
	else if (tick == 60){
		DcMotor1_Stop();

	}
	else if (tick ==72){
		DcMotor1_Rotate(CCW, 255);

	}
	else if(tick == 132){

		DcMotor1_Stop();
		timer1.prescaler = TIMER_STOP;
		Timer1_init(&timer1);
		tick = 0;
		check_point=2 ; //go to the next state
	}
}


void function2_isr(void){
	tick++;
	if(tick == 1){
		activate_buzzer();
	}
	else if (tick == 240){
		tick=0;
		deacitvate_buzzer();
		timer1.prescaler=TIMER_STOP;
		Timer1_init(&timer1);
		Timer1_deinit();
		check_point = 2;
	}

}


void state1(void){ // receiving the first password
	UART_receiveString(pass_stored);
	for (char i = 0 ; i < 5; i++){
		EEPROM_writeByte(0x0311+i, pass_stored[i]);
		_delay_ms(10);
	}
	check_point = 2;

}


void state2(void){ // CHECK THE PASSWORD FOR THE + OPTION
	char receive = UART_recieveByte();
	{
		char check = 1;
		UART_receiveString(pass_got_from_user);
		for(char i = 0 ; i < 5 ; i++){
			if(pass_got_from_user[i] != pass_stored[i]){
				check = 0;
			}
		}

		if(check == 1 && receive == 'M'){
			Timer1_init(&timer1);
			check_point = 3;
		}
		else if (check == 1 && receive == 'P'){
			UART_sendByte('?'); // means that the process will be repeated
					check_point = 1;
		}
		else if (check ==0 ){
			count_loss ++;
			UART_sendByte('C');
		}
		if(count_loss == 2){
			check_point = 4;
			UART_sendByte('!');//go to the error message screen
		}
	}
}

void state3(void){//OPEN THE DOOR

	UART_sendByte('S');


}

void state4(void){ //activating the buzzer
	TIMER1_setCallBack(function2_isr);
	Timer1_init(&timer1);
}






int main (void){
	SREG = 1<<7;
	UART_ConfigType UARt = {BAUD_RATE7,ONE_BIT,EIGHT_BIT,DISABLED};
	UART_init(&UARt);
	TWI_init();
	TIMER1_setCallBack(function_isr);
	DcMotor1_Init();



	while(1){
		switch (check_point){
			case 1:
				state1();
				break;
			case 2:

				state2();
				break;
			case 3:

			state3();

				break;
//			case 4:
//				state4();
//				break;
		}

	}
}

