/*
 * APP.h
 *
 *  Created on: Oct 30, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef APP_APP_H_
#define APP_APP_H_

#include "../HAL/BUZZER_Module/BUZZER.h"
#include "../HAL/DC_Motor_Module/DC_Motor.h"
#include "../HAL/EEPROM/EEPROM.h"
#include "../MCAL/UART/uart.h"
#include <avr/interrupt.h>

#endif /* APP_APP_H_ */
