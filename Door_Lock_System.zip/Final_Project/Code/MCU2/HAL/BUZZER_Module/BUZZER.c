/*
 * BUZZER.c
 *
 *  Created on: Oct 28, 2023
 *      Author: Youssef Ali Sallam
 */
#include "BUZZER.h"


void activate_buzzer(void){
	GPIO_setupPinDirection(BUZZER_PORT, BUZZER_PIN, PIN_OUTPUT);
	GPIO_writePin(BUZZER_PORT, BUZZER_PIN, LOGIC_HIGH);
}
void deacitvate_buzzer(void){
	GPIO_setupPinDirection(BUZZER_PORT, BUZZER_PIN, PIN_OUTPUT);
	GPIO_writePin(BUZZER_PORT, BUZZER_PIN, LOGIC_LOW);
}

