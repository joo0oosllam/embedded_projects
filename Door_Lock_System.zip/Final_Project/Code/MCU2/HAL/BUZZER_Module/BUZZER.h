/*
 * BUZZER.h
 *
 *  Created on: Oct 28, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef HAL_BUZZER_MODULE_BUZZER_H_
#define HAL_BUZZER_MODULE_BUZZER_H_

#include "../../MCAL/GPIO_Module/gpio.h"

#define BUZZER_PORT     PORTC_ID
#define BUZZER_PIN 		PIN7_ID



void activate_buzzer(void);
void deacitvate_buzzer(void);

#endif /* HAL_BUZZER_MODULE_BUZZER_H_ */
