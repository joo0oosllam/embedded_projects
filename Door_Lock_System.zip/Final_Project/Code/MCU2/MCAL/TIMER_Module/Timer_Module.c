/*
 * Timer0.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#include "Timer_Module.h"
#include "../GPIO_Module/gpio.h"


static volatile void (*g_callBackPtr)(void) = NULL_PTR;

void Timer0_deinit(void){
	TCCR0 &=0x07;
	TCNT0 = 0;
	OCR0 = 0;
	TIMSK &=0xFC ;
	TIFR &=0xFC;
}

void Timer1_deinit(void){
	TCCR1A=0;
	TCCR1B=0;
	TCNT1 = 0;
	OCR1A= 0;
	OCR1B = 0;
	TIMSK &=0xC3 ;


}



void Timer0_init(const TIMER0_init_parameters_config * _ptr){
	TCCR0 = _ptr->prescaler;
		switch (_ptr->mode){
		case TIMER_NORMAL_T0:
			Timer0_deinit();
			TCCR0 |= 1<<FOC0;
			TIMSK = 1 ;
			TCNT0 = _ptr->timer_initial_value;


			break;
		case CTC_T0:
			Timer0_deinit();
			TIMSK = 2;
			TCCR0 |= 1<<FOC0;
			TCCR0 |=1<<WGM01;
			TCCR0 &= 0xCF;
			TCCR0 |= (_ptr->Compare_Config_CTC)<<4;

			break;
		case FAST_PWM_T0:
			Timer0_deinit();
			TCCR0 |=1<<WGM01 | 1<<WGM00;
			TCCR0 &= 0xCF;
			TCCR0 |= (_ptr->Compare_Config_PWM)<<4;
			OCR0 = _ptr->OCR;
			break;


}
}
void Timer1_init( TIMER1_init_parameters_config * _ptr){/*THIS WILL BE NOTED BY USING ONLY ONE COMPARE REGISTER*/
	switch (_ptr->mode) {
		case TIMER_NORMAL_T1:
			Timer1_deinit();
			TCCR1B |= _ptr->prescaler;
			TCCR1A |= 1<<FOC1A;
			TCNT1 = _ptr->timer_initial_value;

			break;
		case CTC_T1 :
//		  Timer1_deinit();
			TCNT1 = _ptr->timer_initial_value; //Set Timer1 initial value
			OCR1A = _ptr->OCR;  //Set compare value
			TIMSK |= (1<<OCIE1A); //Enable Timer1 Compare match Interrupt
			TCCR1A = (1<<FOC1A);
			TCCR1B = (TCCR1B & 0XF8) | (_ptr->prescaler);
			TCCR1B |= (1<<WGM12);
			break;

}
}


void TIMER1_setCallBack(void(*a_ptr)(void))
{
	/* Save the address of the Call back function in a global variable */
	g_callBackPtr = a_ptr;
}


ISR (TIMER1_COMPA_vect){



		if(g_callBackPtr != NULL_PTR)
		{
			(*g_callBackPtr)();
		}

}






/**
ISR(TIMER0_OVF_vect){
	//callback function will be called here and implemented in the APP.c File
}
																							this block must be unblocked and insert within it the function that is called back
ISR(TIMER0_COMP_vect){
	//callback function will be called here and implemented in the APP.c File
}
**/

void speed_PWM(uint8 velocity){
	GPIO_setupPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT);
				TCCR0 |= (1<<WGM00)|(1<<WGM01)|(1<<COM01);
				TCNT0=0;
				//TCCR0 &= 0x8f;             		if I uncomment this line the PWM will not work why ?
				TCCR0 |= TIMER_CLOCK_PRESCALER_DIV8;
				OCR0 = velocity;
}


//ISR(TIMER0_OVF_vect){
//
//}

