/*
 * Timer0.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef MCAL_TIMER0_MODULE_TIMER0_H_
#define MCAL_TIMER0_MODULE_TIMER0_H_
#include "../GPIO_Module/gpio.h"
#include <avr/interrupt.h>
#include <avr/io.h>

#define PWM_PORT 	PORTB_ID
#define PWM_PIN		PIN3_ID



typedef enum {
	Timer0,
	Timer1,
	Timer2
}Timer_name;

typedef enum {
	TIMER_STOP,
	TIMER_CLOCK_PRESCALER_DIV1,
	TIMER_CLOCK_PRESCALER_DIV8,
	TIMER_CLOCK_PRESCALER_DIV64,
	TIMER_CLOCK_PRESCALER_DIV256,
	TIMER_CLOCK_PRESCALER_DIV1024,
	EXTERNAL_FALLING,
	EXTERNAL_RISING
}TIMER_prescaler_DIV;

typedef enum {
	TIMER_NORMAL_T0,
	CTC_T0=2,
	FAST_PWM_T0
}TIMER0_MODE;

typedef enum {
	TIMER_NORMAL_T1,
	CTC_T1=2,

}TIMER1_MODE;

typedef enum{
	Normal_OC_Disconnected_CTC,
	Toggle_On_Match,
	Clear_On_Match,
	Set_On_Match,
}Compare_Output_Mode_CTC;

typedef enum{
	Normal_OC0_Disconnected_PWM,
	Non_Inverting=2,
	Inverting,
}Compare_Output_Mode_FAST_PWM;

typedef struct {

	TIMER0_MODE mode;
	TIMER_prescaler_DIV prescaler;
	uint8 timer_initial_value;
	Compare_Output_Mode_CTC Compare_Config_CTC;
	Compare_Output_Mode_FAST_PWM Compare_Config_PWM;
	uint8 OCR;


}TIMER0_init_parameters_config;

typedef struct {

	TIMER1_MODE mode;
	TIMER_prescaler_DIV prescaler;
	uint8 timer_initial_value;
	Compare_Output_Mode_CTC Compare_Config_CTC;
	uint16 OCR;


}TIMER1_init_parameters_config;



void Timer0_init(const TIMER0_init_parameters_config * _ptr);
void Timer0_deinit(void);
void Timer1_init( TIMER1_init_parameters_config * _ptr);
void Timer1_deinit(void);
void TIMER1_setCallBack(void(*a_ptr)(void));
void speed_PWM(uint8 velocity); //this is the only function that is used in the project, the rest of the driver will be used later



#endif /* MCAL_TIMER0_MODULE_TIMER0_H_ */
