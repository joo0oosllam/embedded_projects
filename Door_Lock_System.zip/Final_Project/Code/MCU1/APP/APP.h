/*
 * APP.h
 *
 *  Created on: Oct 30, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef APP_APP_H_
#define APP_APP_H_
#include "../HAL/KEYPAD_Module/keypad.h"
#include "../HAL/LCD_Module/lcd.h"
#include "../MCAL/UART/uart.h"



#endif /* APP_APP_H_ */
