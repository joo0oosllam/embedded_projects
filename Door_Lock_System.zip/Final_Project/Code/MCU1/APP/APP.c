/*
 * APP.c
 *
 *  Created on: Oct 30, 2023
 *      Author: Youssef Ali Sallam
 */
#include "APP.h"
#include <avr/interrupt.h>
//void function(void){															/*THIS IS THE CALLBACK FUNCTION THAT IS GOING TO BE PASSED AS AN ARGUMENT TO BE THE ISR*/
//	GPIO_setupPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT);
//	GPIO_writePin(PORTB_ID, PIN3_ID, LOGIC_HIGH);
//}



//TIMER1_init_parameters_config time_her = { CTC ,TIMER_CLOCK_PRESCALER_DIV1024,0,Normal_OC_Disconnected_CTC, 977*30};

char pass[7]={0,0,0,0,0,'#','\0'};
char pass_repeated[7]={0,0,0,0,0,'#','\0'};
char operating_pass[7]={0,0,0,0,0,'#','\0'};
char check_point = 1;
char count_pass = 0;
char count_repeated = 0;
char count_operating = 0;
char L_counter = 0; //to make it have the same value even after calling the function again
char receive = 0 ;
char L_flag = 0; //flag = 1 when the password entered is correct
char tick = 0;
char flag = 0;
TIMER1_init_parameters_config timer1= {CTC_T1,TIMER_CLOCK_PRESCALER_DIV1024,0,Normal_OC_Disconnected_CTC,2000}; // this timer is counting 0.25 second each interrupt


void function1_isr(void){
	GPIO_setupPinDirection(PORTA_ID, PIN7_ID, PIN_OUTPUT);
								GPIO_writePin(PORTA_ID, PIN7_ID, LOGIC_HIGH);

	tick++;
	if(tick == 1){
		LCD_clearScreen();
		LCD_moveCursor(0, 0);
		LCD_displayString("opening the door");


	}
	else if (tick == 60){
		LCD_clearScreen();
				LCD_moveCursor(0, 0);
				LCD_displayString("door stops");

	}
	else if (tick ==72){
		LCD_clearScreen();
				LCD_moveCursor(0, 0);
				LCD_displayString("closing the door");

	}
	else if(tick == 132){

		timer1.prescaler = TIMER_STOP;
		Timer1_init(&timer1);
		tick = 0;
		flag = 0;
		check_point=2 ; //return to the options menu
	}
}


void function2_isr(void){
	tick++;
	if(tick == 1){
		LCD_clearScreen();
		LCD_moveCursor(0, 0);
		LCD_displayString("ERROR!!!!");
	}
	else if (tick == 240){
		tick=0;
		timer1.prescaler=TIMER_STOP;
		Timer1_init(&timer1);
		Timer1_deinit();
		check_point = 2;
	}

}

void enter_the_password(void){
	LCD_clearScreen();
		LCD_moveCursor(0, 0);
	LCD_displayString("plz enter pass");
	LCD_moveCursor(1, 0);
	while(1){
		if(count_pass<5){
				if(KEYPAD_getPressedKey()>=0 && KEYPAD_getPressedKey()<=9){

							LCD_displayCharacter('*');
							pass[count_pass]=KEYPAD_getPressedKey();
							_delay_ms(500);
							count_pass++;

						}

				}
		else {
			count_pass=0;
			break;
		}
	}

}
void reenter_the_password(void){
	LCD_clearScreen();
	LCD_moveCursor(0, 0);
	LCD_displayString("plz re-enter");
		LCD_moveCursor(1, 0);
		while(1){
			if(count_repeated<5){
					if(KEYPAD_getPressedKey()>=0 && KEYPAD_getPressedKey()<=9){

						LCD_displayCharacter('*');
								pass_repeated[count_repeated]=KEYPAD_getPressedKey();
								_delay_ms(500);
								count_repeated++;

							}

					}
			else {
				count_repeated=0;
				break;
			}
		}

}

uint8 check_the_password(void){
	uint8 result = 1;
	for (int i =0 ; i<5 ; i++){
		if(pass[i] != pass_repeated[i]){
			result = 0;
		}
	}

	return result;
}

void state1(void){
	do{
		enter_the_password();
		reenter_the_password();
	}while(check_the_password()==0 && KEYPAD_getPressedKey()!='^' );
	//here we must send the password to the MCU2 to save it in the I2C EEPROM


}

uint8 state2(void){ //options menu
	uint8 result = 0;
	LCD_clearScreen();
	LCD_moveCursor(0, 0);
	LCD_displayString("+ : Open Door");
	LCD_moveCursor(1, 0);
	LCD_displayString("- : change pass");
	if(KEYPAD_getPressedKey() == '+' || KEYPAD_getPressedKey() == '-'){
		result = KEYPAD_getPressedKey();
		if(result == '+'){
			UART_sendByte('M');
			check_point=3;
		}
		else if (result == '-'){
			UART_sendByte('P');
			check_point=4;
		}
		return result;
	}

}

void state3(void){//open the door branch
	static char L_counter = 0; //to make it have the same value even after calling the function again
	char receive = 0 ;
	char flag = 0;
	LCD_clearScreen();
	LCD_moveCursor(0, 0);
	LCD_displayString("3 enter pass");
	LCD_moveCursor(1, 0);
	while(1){
		if(count_operating<5 && KEYPAD_getPressedKey()!='^' ){
				if(KEYPAD_getPressedKey()>=0 && KEYPAD_getPressedKey()<=9){
					LCD_displayCharacter('*');
					operating_pass[count_operating]=KEYPAD_getPressedKey();
					_delay_ms(500);
					count_operating++;


				}

				}
		else {
			count_operating=0;
			break;
		}
	}
	UART_sendString(operating_pass);
	_delay_ms(500);
	receive=UART_recieveByte();
	if(receive == 'K'){
		check_point = 7; //go to the error message
	}
	else if(receive == 'S'){
			Timer1_init(&timer1);
			receive = 0;

		}

}


void state4(void){//changing the password branch
	char receive = 0;
	LCD_clearScreen();
	LCD_moveCursor(0, 0);
	LCD_displayString("enter old pass");
	LCD_moveCursor(1, 0);
	while(1){
		if(count_operating<5){
				if(KEYPAD_getPressedKey()>=0 && KEYPAD_getPressedKey()<=9){
					LCD_displayCharacter('*');
					operating_pass[count_operating]=KEYPAD_getPressedKey();
					_delay_ms(500);
					count_operating++;

				}

				}
		else {
			count_operating=0;
			break;
		}
	}
	UART_sendString(operating_pass);
	_delay_ms(500);

	receive = UART_recieveByte();
	if (receive == '?'){
	check_point = 1;

	}
	else if (receive == '!'){
		check_point = 5;
	}
	else if (receive == 'C'){
		LCD_clearScreen();
	}


}


void state5(void){
	LCD_clearScreen();
	TIMER1_setCallBack(function2_isr); //to make the new function of the ISR in this case
	Timer1_init(&timer1);
}


int main (void){
	SREG = 1<<7;
//	GPIO_setupPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT);
//	TIMER1_setCallBack(function);
//	Timer1_init(&time_her);
	LCD_init();
	UART_ConfigType UARt = {BAUD_RATE7,ONE_BIT,EIGHT_BIT,DISABLED};
	UART_init(&UARt);
	TIMER1_setCallBack(function1_isr);

	while(1){

			switch (check_point){
				case 1:
					state1();
					if(KEYPAD_getPressedKey()=='^'){
						_delay_ms(500);
						UART_sendString(pass_repeated);
						LCD_clearScreen();
						check_point++;

					}
					break;
				case 2:
					state2();
					LCD_clearScreen();

					break;
				case 3:
					if (flag == 0){
						state3();
						flag = 1;
					}


					break;

				case 4:

					state4();
					LCD_clearScreen();


					break;

				case 5:

					state5();
					LCD_clearScreen();
					break;
			}








	}


	return 0;
}


