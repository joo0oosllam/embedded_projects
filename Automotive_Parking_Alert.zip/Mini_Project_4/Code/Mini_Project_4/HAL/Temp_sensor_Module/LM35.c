/*
 * LM35.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#include "LM35.h"

uint16 LM35_Temperature(void){
	uint8 result;

	result = (uint8)(((uint32)(ADC_readChannel(SENSOR_PIN))*SENSOR_MAX_TEMP*(ADC_Vref))/(ADC_precesion*SENSOR_MAX_VOLT));

	return result ;
}
