/*
 * ULTRA.c
 *
 *  Created on: Oct 12, 2023
 *      Author: Youssef Ali Sallam
 */


#include "ultrasonic.h"


extern uint8 g_edgeCount=0;
extern uint16 time=0;

void Ultrasonic_init(void){
	ICU_setCallBack(Ultrasonic_edgeProcessing);
	GPIO_setupPinDirection(TRIGGER_PORT,TRIGGER_PIN,PIN_OUTPUT);
	GPIO_setupPinDirection(ECHO_PORT,ECHO_PIN,PIN_INPUT);

}
 void Ultrasonic_Trigger(void){
GPIO_writePin(PORTB_ID,PIN5_ID,LOGIC_HIGH);
_delay_us(10);
GPIO_writePin(PORTB_ID,PIN5_ID,LOGIC_LOW);
 }

 uint16 Ultrasonic_readDistance(void){
	 Ultrasonic_Trigger();
	 return ((time / 58)+1);
 }
 /*
  *	Description : processing the signal will be in this order:
  *		1-checking the count of the edges
  *		2-if 1 -> (that means that we just captured the first interrupt) restart the timer reconfigure the ICU for the falling edge to catch the second interrupt
  *		3-if 2 -> (that means that we captured our second interrupt) so we will update the value of the timer with the counted then we will clear the timer for another calculation
  *					after that we will reconfigure the edge value to rising again after that reseting the value of the edges-counter
  *
  *		this function is occurring each time the interrupt happens and this is the callback function that will be called in the ISR
  *
  * */
 void Ultrasonic_edgeProcessing(void){
	  g_edgeCount++;
	 	if(g_edgeCount == 1)
	 	{
	 		ICU_clearTimerValue();
	 		ICU_setEdgeDetectionType(FALLING);
	 	}
	 	else if(g_edgeCount == 2)
	 	{

	 		time = ICU_getInputCaptureValue();
	 		ICU_clearTimerValue();

	 		ICU_setEdgeDetectionType(RAISING);
	 		g_edgeCount = 0;
	 	}

 }
