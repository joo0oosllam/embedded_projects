/*
 * ULTRA.h
 *
 *  Created on: Oct 12, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef ULTRA_H_
#define ULTRA_H_

//#include"std_types.h"
#include"../../MCAL/GPIO_Module/gpio.h"
#include"../../MCAL/std_types.h"
#include"../../MCAL/ICU_Module/ICU.h"
#include <util/delay.h>


#define ECHO_PORT		PORTD_ID
#define ECHO_PIN		PIN6_ID

#define TRIGGER_PORT	PORTB_ID
#define TRIGGER_PIN		PIN5_ID

 void Ultrasonic_init(void);
 void Ultrasonic_Trigger(void);
 uint16 Ultrasonic_readDistance(void);
 void Ultrasonic_edgeProcessing(void);



#endif /* ULTRA_H_ */
