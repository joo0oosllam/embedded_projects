/*
 * DC_Motor.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */


#include "DC_Motor.h"
float Speed;            // this variable is shared to the APP.c file (extern)
void DcMotor1_Init(void){
	GPIO_setupPinDirection(MOTOR1_PORT, MOTOR1_PIN_POSITIVE,PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR1_PORT, MOTOR1_PIN_NEGATIVE,PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR1_PORT, MOTOR1_PIN_ENABLE,PIN_OUTPUT);

	/*
	 * to stop the motor at the beginning we only need to set the enable pin to low
	 * */
	GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_POSITIVE, LOGIC_LOW);
	GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_NEGATIVE, LOGIC_LOW);
	GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_ENABLE, LOGIC_LOW);

}
void DcMotor1_Rotate(DcMotor_State state,uint8 speed){
	if(state == CW){
	GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_POSITIVE, LOGIC_HIGH);
	GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_NEGATIVE, LOGIC_LOW);
	speed_PWM(speed);
	Speed = (((float)speed)/255)*100;
	}
	else{
		GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_POSITIVE, LOGIC_LOW);
		GPIO_writePin(MOTOR1_PORT, MOTOR1_PIN_NEGATIVE, LOGIC_HIGH);
	}
}

void DcMotor1_Stop(void){
	speed_PWM(0);
}


float get_speed_motor1(void){
	return ((Speed/255)*100);
}





void DcMotor2_Init(void){
	GPIO_setupPinDirection(MOTOR2_PORT, MOTOR2_PIN_POSITIVE,PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR2_PORT, MOTOR2_PIN_NEGATIVE,PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR2_PORT, MOTOR2_PIN_ENABLE,PIN_OUTPUT);

	/*
	 * to stop the motor at the beginning we only need to set the enable pin to low
	 * */
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_POSITIVE, LOGIC_LOW);
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_NEGATIVE, LOGIC_LOW);
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_ENABLE, LOGIC_LOW);

}
void DcMotor2_Rotate(DcMotor_State state,uint8 speed){
	if(state == CW){
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_POSITIVE, LOGIC_HIGH);
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_NEGATIVE, LOGIC_LOW);
	}
	else{
		GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_POSITIVE, LOGIC_LOW);
		GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_NEGATIVE, LOGIC_HIGH);
	}

}



void DcMotor2_Stop(void){
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_ENABLE, LOGIC_LOW);
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_POSITIVE, LOGIC_LOW);
	GPIO_writePin(MOTOR2_PORT, MOTOR2_PIN_NEGATIVE, LOGIC_LOW);
}

