/*
 * Timer0.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef MCAL_TIMER0_MODULE_TIMER0_H_
#define MCAL_TIMER0_MODULE_TIMER0_H_
#include "../GPIO_Module/gpio.h"
#include <avr/io.h>


typedef enum {
	TIMER_STOP,
	TIMER_CLOCK_PRESCALER_DIV1,
	TIMER_CLOCK_PRESCALER_DIV8,
	TIMER_CLOCK_PRESCALER_DIV64,
	TIMER_CLOCK_PRESCALER_DIV256,
	TIMER_CLOCK_PRESCALER_DIV1024,
	EXTERNAL_FALLING,
	EXTERNAL_RISING
}TIMER_prescaler_DIV;

typedef enum {
	TIMER_NORMAL,
	CTC=2,
	FAST_PWM
}TIMER0_MODE;

typedef enum{
	Normal_OC0_Disconnected_CTC,
	Toggle_On_Match,
	Clear_On_Match,
	Set_On_Match,
}Compare_Output_Mode_CTC;

typedef enum{
	Normal_OC0_Disconnected_PWM,
	Non_Inverting=2,
	Inverting,
}Compare_Output_Mode_FAST_PWM;

typedef struct {

	TIMER0_MODE mode;
	TIMER_prescaler_DIV prescaler;
	uint8 timer_initial_value;
	Compare_Output_Mode_CTC Compare_Config_CTC;
	Compare_Output_Mode_FAST_PWM Compare_Config_PWM;
	uint8 OCR;
	float duty;  //    0->1


}TIMER0_init_parameters_config;


void Timer0_init(const TIMER0_init_parameters_config * _ptr);
void Timer0_deinit(void);
void speed_PWM(uint8 velocity); //this is the only function that is used in the project, the rest of the driver will be used later



#endif /* MCAL_TIMER0_MODULE_TIMER0_H_ */
