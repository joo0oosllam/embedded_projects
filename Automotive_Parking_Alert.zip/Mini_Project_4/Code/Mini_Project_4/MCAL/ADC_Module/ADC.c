/*
 * ADC.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#include "ADC.h"
void ADC_init(const ADC_init_parameters_config * _ptr){
	ADMUX = 0;
	ADCSRA = (1<<ADEN);
	ADCSRA &= 0xF8 ;
	ADCSRA |= _ptr->prescaler;
	ADMUX &=0x3F;
	ADMUX |= ((_ptr->ref)<<6);

}
uint16 ADC_readChannel(uint8 channel_number){
	/**
	 * 1-insert the channel number, so we will have to use the insertion technique in the ADMUX to
	 * 2-
	 *
	 * */

	uint16 result;
	ADMUX &= 0xE8;
	ADMUX |= (channel_number);
	ADCSRA |= 1<<ADSC ;
	while(!(ADCSRA&(1<<ADIF))){}
	result = ADC;
	ADCSRA |= 1<<ADIF ;
	return result ;

}
