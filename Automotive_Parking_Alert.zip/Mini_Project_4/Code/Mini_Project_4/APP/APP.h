/*
 * APP.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef APP_APP_H_
#define APP_APP_H_
#include "../HAL/LCD_Module/lcd.h"
#include "../HAL/UltraSonic_Module/ultrasonic.h"

#endif /* APP_APP_H_ */
