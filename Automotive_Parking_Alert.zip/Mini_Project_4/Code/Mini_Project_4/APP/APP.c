/*
 * main.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */
#include "../MCAL/ICU_Module/ICU.h"
#include <avr/io.h>
#include"../HAL/LCD_Module/lcd.h"
#include "../HAL/UltraSonic_Module/ultrasonic.h"

#define F_CPU 8000000UL



int main(){
	 float distance=0;
	 ICU_ConfigType ICU_Configurations = {F_CPU_8,RAISING};
	/* Enable Global Interrupt I-Bit */
	SREG |= (1<<7);
	LCD_init();
	ICU_init(&ICU_Configurations);
	Ultrasonic_init();

	while(1){
	distance=(float)Ultrasonic_readDistance();
	LCD_moveCursor(1,0);
	if (distance>=100){
		LCD_displayString("Distance=   cm");
	LCD_moveCursor(1,9);
    LCD_intgerToString(distance);

	}
	else{
		LCD_displayString("Distance=   cm");
			LCD_moveCursor(1,9);
		    LCD_intgerToString(distance);
	}

	}
	}
