#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
char seconds1 = 0;
char minutes1 = 1;
char minutes2 = 1;
char seconds2 = 0;
char flag_player = 0;

void timer1_init(void){ /*to begin the timer with no clock source (timer is paused)*/
	SREG = 1<<7;
	TCCR1A = 1<<FOC1A ;
	TCCR1B = 1<<WGM12 ;
	TCNT1=0;
	OCR1A=977;//to calculate just one second
	TIMSK=1<<OCIE1A;
}

ISR(TIMER1_COMPA_vect){
	if(flag_player==0){

		if(seconds1==0){
			minutes1--;
			seconds1=59;
		}
		seconds1--;
	}
	else{

		if(seconds2==0){
			minutes2--;
			seconds2=59;
		}
		seconds2--;
	}

}





void int2_init(void){

	GICR|=1<<INT2; /*to enable interrupt2 and it has only two modes rising or falling */

}

ISR(INT2_vect){/*the functionality of this interrupt is to resume the timer after being paused by INT1
				and we are doing so by re-energizing the timer with the same clock settings that we
				initialized the clock with at the start of the program.

 	 	 	 	*/
	TCCR1B = 1<<WGM12 | 1<<CS12 | 1<<CS10;
}


void increase_seconds(void){
	DDRD=0;
	if(PIND&(1<<3)){
		_delay_ms(5);
		if(PIND&(1<<3)){
			seconds1++;
			seconds2++;
			while(PIND&(1<<3)){}
		}
	}
}

void increase_minutes(void){
	DDRD=0;
	if(!(PIND&(1<<2))){
		_delay_ms(5);
		if(!(PIND&(1<<2))){
			minutes1++;
			minutes2++;
			while(!(PIND&(1<<2))){}
		}
	}
}


void time_out1(void){/*checks if player1 finished his time*/

	if (seconds1==0 && minutes1==0){
		TCCR1B &=~ (1<<CS12 | 1<<CS10);
		PORTB |=1<<7;
	}

}

void time_out2(void){ /*checks if player2 finished his time*/

	if (seconds2==0 && minutes2==0){
		TCCR1B &=~ (1<<CS12 | 1<<CS10);
		PORTB |=1<<6;
	}

}


/**
 * this function is dedicated to display the numbers by looping the entire seven segments to
 * get the corresponding number and display it in the right direction
 * */
void display(void){

	char second1_1=seconds1%10;
	char second1_2=((seconds1 - seconds1%10)/10)%10;
	char second2_1= seconds2%10;
	char second2_2= ((seconds2 - seconds2%10)/10)%10;
	char minute1=minutes1;
	char minute2=minutes2;


	PORTA=1<<0;
	PORTC=second1_1;
	_delay_ms(1);
	PORTA=1<<1;
	PORTC=second1_2;
	_delay_ms(1);
	PORTA=1<<2;
	PORTC=minute1;
	_delay_ms(1);
	PORTA=1<<3;
	PORTC=second2_1;
	_delay_ms(1);
	PORTA=1<<4;
	PORTC=second2_2;
	_delay_ms(1);
	PORTA=1<<5;
	PORTC=minute2;
	_delay_ms(1);

}





int main(void){
	DDRD=0;

	DDRB=0;
	DDRB|= 1<<7;
	DDRB|= 1<<6;
	PORTD|=1<<2;
	PORTB|=1<<2;
	DDRC=0x0F;
	DDRA=0x3F;
	PORTC=0;
	PORTA=0;
	timer1_init();
	int2_init();
	while(1){
		if(!((TCCR1B) & (1<<CS12 | 1<<CS10)))
			{
			increase_seconds();
			increase_minutes();

			}
		if(PIND&1){//second player's turn
			flag_player=1;
		}
		else if((PIND&(1<<0))==0) {//first player's turn
			flag_player = 0;
		}

		/*always display the number on the 7-segments*/
		display();
		/*
		 * time_out1 and time_out2 check each clock cycle if there is anyone has
		 * finished his time*/
		time_out1();
		time_out2();



	}

}
