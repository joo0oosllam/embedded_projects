/*
 * APP.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#include "APP.h"



extern volatile float Speed;  /*here I used data sharing method in order to get the value of the current speed from the DC-Motor Module*/

char state[2][3]={{"OFF"},{"ON"}};

ADC_init_parameters_config adc = {
	.ref=Internal,
	.prescaler=ADC_CLOCK_PRESCALER_DIV8
};

int main(void){
	ADC_init(&adc);
	DcMotor1_Init();
	LCD_init();
	LCD_moveCursor(1, 3);
	uint16 temperature;
	uint8 status;

	while(1){

		LCD_moveCursor(1, 3);
		temperature=LM35_Temperature();
		if(temperature<30){status=0;}
		else {status=1;}

		if(temperature<30){
			DcMotor1_Stop();
			LCD_moveCursor(0, 0);
			LCD_displayString("FAN is OFF");
			LCD_displayCharacter(' ');
			LCD_moveCursor(0, 13);
			LCD_intgerToString(Speed);
			LCD_displayCharacter('%');
			LCD_moveCursor(1, 3);
			LCD_displayString("Temp = ");
			LCD_intgerToString(temperature);
			LCD_displayCharacter('C');

		}
		else if((temperature>=30) &&temperature<60){
			DcMotor1_Rotate(CW,64);
			LCD_moveCursor(0, 0);
			LCD_displayString("FAN is ON");
			LCD_displayCharacter(' ');
			LCD_moveCursor(0, 13);
			LCD_intgerToString(Speed);
			LCD_displayCharacter('%');
			LCD_moveCursor(1, 3);
			LCD_displayString("Temp = ");
			LCD_intgerToString(temperature);
			LCD_displayCharacter('C');
		}
		else if(temperature>=60 && temperature<90){
			DcMotor1_Rotate(CW,128);
			LCD_moveCursor(0, 0);
			LCD_displayString("FAN is ON");
			LCD_displayCharacter(' ');
			LCD_moveCursor(0, 13);
			LCD_intgerToString(Speed);
			LCD_displayCharacter('%');
			LCD_moveCursor(1, 3);
			LCD_displayString("Temp = ");
			LCD_intgerToString(temperature);
			LCD_displayCharacter('C');
				}
		else if(temperature>=90 &&temperature<120){
			DcMotor1_Rotate(CW,192);
			LCD_moveCursor(0, 0);
			LCD_displayString("FAN is ON");
			LCD_displayCharacter(' ');
			LCD_moveCursor(0, 13);
			LCD_intgerToString(Speed);
			LCD_displayCharacter('%');
			LCD_moveCursor(1, 3);
			LCD_displayString("Temp = ");
			LCD_intgerToString(temperature);
			LCD_displayCharacter('C');
				}
		else if(temperature>=120 ){
			DcMotor1_Rotate(CW,255);
			LCD_moveCursor(0, 0);
			LCD_displayString("FAN is ON");
			LCD_displayCharacter(' ');
			LCD_moveCursor(0, 12);
			LCD_intgerToString(Speed);
			LCD_displayCharacter('%');
			LCD_moveCursor(1, 3);
			LCD_displayString("Temp = ");
			LCD_intgerToString(temperature);
			LCD_displayCharacter('C');
		}


	}
}
