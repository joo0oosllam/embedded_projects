/*
 * APP.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef APP_APP_H_
#define APP_APP_H_
#include "../HAL/LCD_Module/lcd.h"
#include "../HAL/DC_Motor_Module/DC_Motor.h"
#include "../MCAL/TIMER0_Module/Timer0.h"
#include "../HAL/Temp_sensor_Module/LM35.h"

#endif /* APP_APP_H_ */
