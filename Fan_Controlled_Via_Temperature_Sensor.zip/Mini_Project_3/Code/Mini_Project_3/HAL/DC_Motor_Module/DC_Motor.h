/*
 * DC_Motor.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef HAL_DC_MOTOR_MODULE_DC_MOTOR_H_
#define HAL_DC_MOTOR_MODULE_DC_MOTOR_H_
#include "../../MCAL/GPIO_Module/gpio.h"
#include "../../MCAL/TIMER0_Module/Timer0.h"


#define MOTOR1_PORT PORTB_ID
#define MOTOR2_PORT PORTB_ID

#define MOTOR1_PIN_POSITIVE PIN0_ID
#define MOTOR2_PIN_POSITIVE PIN0_ID

#define MOTOR1_PIN_NEGATIVE PIN1_ID
#define MOTOR2_PIN_NEGATIVE PIN1_ID

#define MOTOR1_PIN_ENABLE PIN3_ID
#define MOTOR2_PIN_ENABLE PIN2_ID

typedef enum {
	CW=1,     		//   01
	CCW=2			//   10
}DcMotor_State;

void DcMotor1_Init(void);
void DcMotor1_Rotate(DcMotor_State state,uint8 speed);
void DcMotor1_Stop(void);
float get_speed_motor1(void);

void DcMotor2_Init(void);
void DcMotor2_Rotate(DcMotor_State state,uint8 speed);
void DcMotor2_Stop(void);

extern volatile uint8 speed;

#endif /* HAL_DC_MOTOR_MODULE_DC_MOTOR_H_ */
