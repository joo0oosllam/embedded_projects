/*
 * LM35.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef HAL_TEMP_SENSOR_MODULE_LM35_H_
#define HAL_TEMP_SENSOR_MODULE_LM35_H_
#include "../../MCAL/GPIO_Module/gpio.h"
#include "../../MCAL/ADC_Module/ADC.h"

#define SENSOR_PIN		 2
#define SENSOR_MAX_TEMP  150
#define SENSOR_MAX_VOLT	 1.5

uint16 LM35_Temperature(void);


#endif /* HAL_TEMP_SENSOR_MODULE_LM35_H_ */
