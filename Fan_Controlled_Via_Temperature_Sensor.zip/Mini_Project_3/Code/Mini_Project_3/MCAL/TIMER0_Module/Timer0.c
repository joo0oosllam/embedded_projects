/*
 * Timer0.c
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#include "Timer0.h"
#include "../GPIO_Module/gpio.h"



void Timer0_deinit(void){
	TCCR0&=0;
	TCNT0 = 0;
	OCR0 = 0;
	TIMSK &= 0xFC; /*because this register is also responsible for the TIMER1 and TIMER2 and we here only focusing on TIMER0*/
}


void Timer0_init(const TIMER0_init_parameters_config * _ptr){
	switch ((_ptr->mode)){

	case TIMER_NORMAL:
		Timer0_deinit();
		TCCR0 |= 1<<FOC0;//for non-PWM modes
		TCCR0 |= (_ptr->prescaler); /*prescaler adjustment*/
		TCNT0 = (*_ptr).timer_initial_value;
		TIMSK =1<<TOIE0;
		//now we must go to the ISR

		break;
	case CTC:
		Timer0_deinit();
		TCCR0 |= 1<<FOC0/**for non-PWM modes*/  |1<<WGM01;
		TCNT0=0; /*this is a redundant/dummy check because this is already configured in the Timer0_deinit() function */
		TCCR0 |= ((_ptr->Compare_Config_CTC)<<4);
		TCCR0 |= (_ptr->prescaler); /*prescaler adjustment*/
		OCR0 = _ptr->OCR;
		TIMSK =1<<OCIE0;
		//now we must go to the ISR

		break;
	case FAST_PWM:
		Timer0_deinit();
		TCCR0 |= 1<<WGM00 | 1<<WGM01;
		TCCR0 |= ((_ptr->Compare_Config_PWM)<<4);
		TCCR0 |= (_ptr->prescaler); /*prescaler adjustment*/
		OCR0 = (uint8)((_ptr->duty)*255*100);
		break;
	}
}


/**
ISR(TIMER0_OVF_vect){
	//callback function will be called here and implemented in the APP.c File
}
																							this block must be unblocked and insert within it the function that is called back
ISR(TIMER0_COMP_vect){
	//callback function will be called here and implemented in the APP.c File
}
**/

void speed_PWM(uint8 velocity){
	GPIO_setupPinDirection(PORTB_ID, PIN3_ID, PIN_OUTPUT);
				TCCR0 |= (1<<WGM00)|(1<<WGM01)|(1<<COM01);
				TCNT0=0;
				//TCCR0 &= 0x8f;             		if I uncomment this line the PWM will not work why ?
				TCCR0 |= TIMER_CLOCK_PRESCALER_DIV8;
				OCR0 = velocity;
}


//ISR(TIMER0_OVF_vect){
//
//}

