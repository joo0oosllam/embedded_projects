/*
 * ADC.h
 *
 *  Created on: Oct 11, 2023
 *      Author: Youssef Ali Sallam
 */

#ifndef MCAL_ADC_MODULE_ADC_H_
#define MCAL_ADC_MODULE_ADC_H_
#include "../GPIO_Module/gpio.h"
#include <avr/io.h>

#define ADC_precesion 	1023
#define ADC_Vref 		2.56


typedef enum {
	AREF,
	AVCC,
	Internal=3
}reference_voltage;

typedef enum {
	ADC_CLOCK_PRESCALER_DIV1,
	ADC_CLOCK_PRESCALER_DIV2,
	ADC_CLOCK_PRESCALER_DIV4,
	ADC_CLOCK_PRESCALER_DIV8,
	ADC_CLOCK_PRESCALER_DIV16,
	ADC_CLOCK_PRESCALER_DIV32,
	ADC_CLOCK_PRESCALER_DIV64,
	ADC_CLOCK_PRESCALER_DIV128,
}ADC_prescaler_DIV;

typedef struct {
	reference_voltage ref;
	ADC_prescaler_DIV prescaler;

}ADC_init_parameters_config;



void ADC_init(const ADC_init_parameters_config * _ptr);
uint16 ADC_readChannel(uint8 channel_number);




#endif /* MCAL_ADC_MODULE_ADC_H_ */
